Pro AngularJS
==================
Contains source codes for [Pro AngularJS](http://www.apress.com/9781430264484) book from Apress by Adam Freeman

### To start the project:

1.  Install [Git](http://git-scm.com/downloads) and [Node.js](http://nodejs.org/)
2.  $ git clone [git@github.com:sbedulin/pro-angularjs-book.git](git@github.com:sbedulin/pro-angularjs-book.git)
3.  $ cd pro-angularjs-book
4.  $ npm install
5.  $ npm install -g bower
6.  $ bower install
7.  $ node server
8.  Open [http://localhost:3001](http://localhost:3001) in a browser