### To run unit tests:

0.  From root *pro-angularjs-book* folder
1.  Run "npm install", this will install *package.json* dependencies including *Karma* and *Jasmine*
2.  Run "npm install -g karma-cli", this will allow to use karma from cmd
3.  Run "karma start app/chapter-25/karma.config.js" to launch unit tests